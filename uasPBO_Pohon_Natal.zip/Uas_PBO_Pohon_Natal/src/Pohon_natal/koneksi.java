package Pohon_natal;

import GUI.tampil_awal;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;


public class koneksi {
    private static String username = "root";
    private static String password = "";
    public ResultSet rs;
    public static Connection con;
    public static Statement stmt;
    static final String DB_URL ="jdbc:mysql://localhost/pbo";
    
    public static Connection connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL,username,password);
            stmt = con.createStatement();
            System.out.println("koneksi Berhasil;");
        } catch (Exception e) {
            System.out.println("koneksi Gagal" );
        }
        return con;
    }
    public static Statement statement(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL,username,password);
            stmt = con.createStatement(); 
            System.out.println("Koneksi Berhasil");
        } catch (Exception e) {
            System.out.println("Koneksi Gagal");
        }
        return stmt;
       
    }

    public static String getPassword() {
        return password;
    }

    public static void setPassword(String password) {
        koneksi.password = password;
    }
        public static void main(String[] args) {
         connect();    
         tampil_awal awal = new tampil_awal();
         awal.setVisible(true);
         
    }
        
}
